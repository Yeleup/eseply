/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: eseply_db
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `accruals`
--

DROP TABLE IF EXISTS `accruals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accruals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `utility_service_id` bigint(20) unsigned DEFAULT NULL,
  `period` varchar(6) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `utility_service_name` varchar(255) DEFAULT NULL,
  `billing_type` varchar(255) NOT NULL,
  `volume` decimal(14,4) DEFAULT NULL,
  `tariff_price` decimal(14,2) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `adjustment_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `closing_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `closed_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accruals_client_period_unique` (`organization_id`,`client_id`,`period`),
  KEY `accruals_client_id_foreign` (`client_id`),
  KEY `accruals_utility_service_id_foreign` (`utility_service_id`),
  KEY `accruals_org_period_idx` (`organization_id`,`period`),
  KEY `accruals_org_account_idx` (`organization_id`,`account_number`),
  CONSTRAINT `accruals_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `accruals_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accruals_utility_service_id_foreign` FOREIGN KEY (`utility_service_id`) REFERENCES `utility_services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accruals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `accruals` WRITE;
/*!40000 ALTER TABLE `accruals` DISABLE KEYS */;
INSERT INTO `accruals` VALUES
(1,1,1,1,'202606','лодллдолд','Сакенов','вода','meter',14.0000,70.00,980.00,0.00,0.00,0.00,980.00,'2026-06-05 09:32:20','2026-06-05 09:32:20','2026-06-05 09:32:20'),
(2,1,2,1,'202606','25327','Байтореев','вода','meter',5.0000,70.00,350.00,0.00,0.00,0.00,350.00,'2026-06-05 09:34:11','2026-06-05 09:34:11','2026-06-05 09:34:11');
/*!40000 ALTER TABLE `accruals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `balance_adjustments`
--

DROP TABLE IF EXISTS `balance_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_adjustments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `period` varchar(6) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'manual_adjustment',
  `amount` decimal(14,2) NOT NULL,
  `adjusted_at` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `balance_adjustments_client_id_foreign` (`client_id`),
  KEY `balance_adjustments_org_period_idx` (`organization_id`,`period`),
  KEY `balance_adjustments_org_client_period_idx` (`organization_id`,`client_id`,`period`),
  CONSTRAINT `balance_adjustments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `balance_adjustments_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_adjustments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `balance_adjustments` WRITE;
/*!40000 ALTER TABLE `balance_adjustments` DISABLE KEYS */;
INSERT INTO `balance_adjustments` VALUES
(1,1,2,'202605','opening_balance',200.00,'2026-05-01',NULL,'2026-06-05 09:36:54','2026-06-05 09:36:54');
/*!40000 ALTER TABLE `balance_adjustments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `utility_service_id` bigint(20) unsigned DEFAULT NULL,
  `account_number` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `iin` text DEFAULT NULL,
  `client_type` varchar(255) NOT NULL DEFAULT 'individual',
  `billing_type` varchar(255) NOT NULL DEFAULT 'per_person',
  `residents_count` int(10) unsigned NOT NULL DEFAULT 1,
  `fixed_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `phone` varchar(255) DEFAULT NULL,
  `contract` text DEFAULT NULL,
  `technical_conditions` text DEFAULT NULL,
  `region_id` bigint(20) unsigned DEFAULT NULL,
  `street_id` bigint(20) unsigned DEFAULT NULL,
  `house` varchar(255) DEFAULT NULL,
  `apartment` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_organization_id_account_number_unique` (`organization_id`,`account_number`),
  KEY `clients_organization_id_status_index` (`organization_id`,`status`),
  KEY `clients_utility_service_id_foreign` (`utility_service_id`),
  KEY `clients_region_id_foreign` (`region_id`),
  KEY `clients_street_id_foreign` (`street_id`),
  CONSTRAINT `clients_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clients_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `clients_street_id_foreign` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `clients_utility_service_id_foreign` FOREIGN KEY (`utility_service_id`) REFERENCES `utility_services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,1,1,'лодллдолд','Сакенов','840524301319','individual','meter',1,0.00,'87083076195','ad-12345',NULL,3,1,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-04 10:48:34'),
(2,1,1,'25327','Байтореев','920713300206','individual','meter',1,0.00,'87083076195','123',NULL,3,1,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-05 09:33:25'),
(3,1,1,'25697','Бердимбетова',NULL,'individual','meter',0,0.00,'87083076195',NULL,NULL,3,1,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-02 06:54:41'),
(4,1,1,'25851','Сырлыбаев Галимжан Сабиевич',NULL,'individual','meter',0,0.00,'87083076195',NULL,NULL,3,1,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-02 06:54:41'),
(5,1,1,'18226','Саденов Мырзатай',NULL,'individual','meter',0,0.00,'87083076195',NULL,NULL,3,1,'бн','','active',NULL,'2026-06-02 06:54:41','2026-06-02 06:54:41'),
(6,1,1,'18227','Куатов Бекзат',NULL,'individual','meter',0,0.00,'87083076195',NULL,NULL,3,1,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-02 06:54:41'),
(7,1,1,'25196','Ербосунова Жанар Тагаевна',NULL,'individual','meter',0,0.00,'87083076195',NULL,NULL,3,NULL,'10','18','active',NULL,'2026-06-02 06:54:41','2026-06-02 10:56:46'),
(8,1,1,'100001','Өтебаев','840524301319','individual','meter',1,0.00,'87083076195','ad-1567765',NULL,3,1,'7','4','active',NULL,'2026-06-04 11:58:26','2026-06-04 11:58:47');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `meter_readings`
--

DROP TABLE IF EXISTS `meter_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meter_readings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `meter_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `utility_service_id` bigint(20) unsigned DEFAULT NULL,
  `period` varchar(6) NOT NULL,
  `previous_reading` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `current_reading` decimal(14,4) NOT NULL,
  `consumption` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `read_at` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `meter_readings_meter_period_unique` (`meter_id`,`period`),
  KEY `meter_readings_client_id_foreign` (`client_id`),
  KEY `meter_readings_utility_service_id_foreign` (`utility_service_id`),
  KEY `meter_readings_org_period_idx` (`organization_id`,`period`),
  KEY `meter_readings_org_client_idx` (`organization_id`,`client_id`),
  CONSTRAINT `meter_readings_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `meter_readings_meter_id_foreign` FOREIGN KEY (`meter_id`) REFERENCES `meters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `meter_readings_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `meter_readings_utility_service_id_foreign` FOREIGN KEY (`utility_service_id`) REFERENCES `utility_services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meter_readings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `meter_readings` WRITE;
/*!40000 ALTER TABLE `meter_readings` DISABLE KEYS */;
INSERT INTO `meter_readings` VALUES
(1,1,1,1,1,'202605',0.0000,4.0000,4.0000,'2026-06-04',NULL,'2026-06-04 09:47:37','2026-06-04 09:47:37'),
(2,1,1,1,1,'202606',4.0000,14.0000,10.0000,'2026-06-04',NULL,'2026-06-04 11:00:38','2026-06-04 11:00:38'),
(3,1,2,1,1,'202606',1.0000,5.0000,4.0000,'2026-06-05',NULL,'2026-06-05 09:31:41','2026-06-05 09:31:41'),
(4,1,5,2,1,'202606',0.0000,5.0000,5.0000,NULL,NULL,'2026-06-05 09:34:05','2026-06-05 09:34:05');
/*!40000 ALTER TABLE `meter_readings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `meters`
--

DROP TABLE IF EXISTS `meters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `utility_service_id` bigint(20) unsigned DEFAULT NULL,
  `number` varchar(255) NOT NULL,
  `installed_on` date DEFAULT NULL,
  `initial_reading` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `removed_on` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `meters_org_number_unique` (`organization_id`,`number`),
  KEY `meters_client_id_foreign` (`client_id`),
  KEY `meters_utility_service_id_foreign` (`utility_service_id`),
  KEY `meters_org_client_status_idx` (`organization_id`,`client_id`,`status`),
  CONSTRAINT `meters_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `meters_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `meters_utility_service_id_foreign` FOREIGN KEY (`utility_service_id`) REFERENCES `utility_services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `meters` WRITE;
/*!40000 ALTER TABLE `meters` DISABLE KEYS */;
INSERT INTO `meters` VALUES
(1,1,1,1,'123456','2026-06-02',0.0000,NULL,'active',NULL,'2026-06-02 06:55:28','2026-06-02 06:55:28'),
(2,1,1,1,'1234567','2026-06-01',1.0000,NULL,'active',NULL,'2026-06-02 06:56:07','2026-06-02 06:56:07'),
(3,1,8,1,'345678','2026-06-01',0.0000,NULL,'active',NULL,'2026-06-04 11:59:11','2026-06-04 11:59:11'),
(4,1,1,1,'99999','2026-06-04',90.0000,'2026-06-04','removed',NULL,'2026-06-04 14:27:28','2026-06-04 14:27:38'),
(5,1,2,1,'12345678',NULL,0.0000,NULL,'active',NULL,'2026-06-05 09:33:49','2026-06-05 09:33:49');
/*!40000 ALTER TABLE `meters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_05_26_073507_create_organizations_table',1),
(5,'2026_05_26_073508_create_organization_user_table',1),
(6,'2026_05_26_081945_create_clients_table',1),
(7,'2026_05_26_083454_create_utility_services_table',1),
(8,'2026_05_26_084947_add_billing_settings_to_clients_table',1),
(9,'2026_05_26_085955_create_tariffs_table',1),
(10,'2026_05_26_093951_create_accruals_table',1),
(11,'2026_05_26_095955_create_meters_table',1),
(12,'2026_05_26_095956_create_meter_readings_table',1),
(13,'2026_05_26_101016_create_payments_table',1),
(14,'2026_05_26_102813_create_receipts_table',1),
(15,'2026_05_28_125040_migrate_tariffs_to_client_types',1),
(16,'2026_05_28_130537_allow_multiple_active_meters_per_client',1),
(17,'2026_05_29_063303_remove_area_from_clients_table',1),
(18,'2026_05_29_064610_create_regions_table',1),
(19,'2026_05_29_064615_create_streets_table',1),
(20,'2026_05_29_071503_replace_client_address_with_region_street_fields',1),
(21,'2026_05_29_095500_add_adjustment_amount_to_accruals_and_receipts_tables',1),
(22,'2026_05_29_095500_create_balance_adjustments_table',1),
(23,'2026_05_29_100347_remove_starting_balance_from_clients_table',1),
(24,'2026_06_04_085133_add_next_client_account_number_to_organizations_table',2),
(25,'2026_06_04_093922_add_client_identity_and_contract_fields_to_clients_table',2),
(26,'2026_06_05_064134_add_role_to_organization_user_table',3),
(27,'2026_06_05_064134_create_organization_user_responsibility_tables',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organization_user`
--

DROP TABLE IF EXISTS `organization_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_user` (
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'operator',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`organization_id`,`user_id`),
  KEY `organization_user_user_id_foreign` (`user_id`),
  KEY `organization_user_role_index` (`role`),
  CONSTRAINT `organization_user_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_user`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organization_user` WRITE;
/*!40000 ALTER TABLE `organization_user` DISABLE KEYS */;
INSERT INTO `organization_user` VALUES
(1,1,'operator','2026-06-01 06:40:19','2026-06-01 06:40:19'),
(1,2,'controller','2026-06-05 07:58:26','2026-06-05 08:01:30');
/*!40000 ALTER TABLE `organization_user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organization_user_regions`
--

DROP TABLE IF EXISTS `organization_user_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_user_regions` (
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `region_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`organization_id`,`user_id`,`region_id`),
  KEY `organization_user_regions_user_id_foreign` (`user_id`),
  KEY `organization_user_regions_region_id_foreign` (`region_id`),
  KEY `org_user_regions_org_region_idx` (`organization_id`,`region_id`),
  CONSTRAINT `org_user_regions_member_foreign` FOREIGN KEY (`organization_id`, `user_id`) REFERENCES `organization_user` (`organization_id`, `user_id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_regions_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_regions_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_regions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_user_regions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organization_user_regions` WRITE;
/*!40000 ALTER TABLE `organization_user_regions` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_user_regions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organization_user_streets`
--

DROP TABLE IF EXISTS `organization_user_streets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_user_streets` (
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `street_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`organization_id`,`user_id`,`street_id`),
  KEY `organization_user_streets_user_id_foreign` (`user_id`),
  KEY `organization_user_streets_street_id_foreign` (`street_id`),
  KEY `org_user_streets_org_street_idx` (`organization_id`,`street_id`),
  CONSTRAINT `org_user_streets_member_foreign` FOREIGN KEY (`organization_id`, `user_id`) REFERENCES `organization_user` (`organization_id`, `user_id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_streets_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_streets_street_id_foreign` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_user_streets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_user_streets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organization_user_streets` WRITE;
/*!40000 ALTER TABLE `organization_user_streets` DISABLE KEYS */;
INSERT INTO `organization_user_streets` VALUES
(1,2,1,'2026-06-05 08:01:30','2026-06-05 08:01:30'),
(1,2,4,'2026-06-05 08:01:30','2026-06-05 08:01:30'),
(1,2,6,'2026-06-05 08:01:30','2026-06-05 08:01:30'),
(1,2,12,'2026-06-05 08:01:30','2026-06-05 08:01:30'),
(1,2,13,'2026-06-05 08:01:30','2026-06-05 08:01:30'),
(1,2,14,'2026-06-05 08:01:30','2026-06-05 08:01:30');
/*!40000 ALTER TABLE `organization_user_streets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `bin_iin` varchar(12) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `iban` varchar(34) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `next_client_account_number` bigint(20) unsigned NOT NULL DEFAULT 100001,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organizations_bin_iin_index` (`bin_iin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES
(1,'Андас тазалык','840524301319','87083076195','Жарокова 194, 38','halyk',NULL,NULL,100002,'2026-06-01 06:40:19','2026-06-04 11:58:26');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `period` varchar(6) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_at` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_client_id_foreign` (`client_id`),
  KEY `payments_org_period_idx` (`organization_id`,`period`),
  KEY `payments_org_client_period_idx` (`organization_id`,`client_id`,`period`),
  CONSTRAINT `payments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `payments_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,1,'202601',200.00,'2026-06-04',NULL,'2026-06-04 10:49:17','2026-06-04 10:49:17'),
(2,1,1,'202602',500.00,'2026-06-04',NULL,'2026-06-04 10:49:57','2026-06-04 10:49:57'),
(3,1,1,'202603',1300.00,'2026-06-04',NULL,'2026-06-04 10:50:23','2026-06-04 10:50:23'),
(4,1,1,'202604',400.00,'2026-04-04',NULL,'2026-06-04 10:50:52','2026-06-04 10:50:52'),
(5,1,1,'202605',50.00,'2026-05-30',NULL,'2026-06-04 11:27:22','2026-06-04 11:27:22');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `accrual_id` bigint(20) unsigned NOT NULL,
  `receipt_number` varchar(255) NOT NULL,
  `period` varchar(6) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `utility_service_name` varchar(255) DEFAULT NULL,
  `billing_type` varchar(255) NOT NULL,
  `volume` decimal(14,4) DEFAULT NULL,
  `tariff_price` decimal(14,2) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `adjustment_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `closing_balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `issued_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipts_accrual_id_unique` (`accrual_id`),
  UNIQUE KEY `receipts_client_period_unique` (`organization_id`,`client_id`,`period`),
  UNIQUE KEY `receipts_org_number_unique` (`organization_id`,`receipt_number`),
  KEY `receipts_client_id_foreign` (`client_id`),
  KEY `receipts_org_period_idx` (`organization_id`,`period`),
  KEY `receipts_org_account_idx` (`organization_id`,`account_number`),
  CONSTRAINT `receipts_accrual_id_foreign` FOREIGN KEY (`accrual_id`) REFERENCES `accruals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `receipts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `receipts_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES
(1,1,1,1,'202606-лодллдолд','202606','лодллдолд','Сакенов','вода','meter',14.0000,70.00,980.00,0.00,0.00,0.00,980.00,'2026-06-05 09:32:20','2026-06-05 09:32:20','2026-06-05 09:32:20'),
(2,1,2,2,'202606-25327','202606','25327','Байтореев','вода','meter',5.0000,70.00,350.00,0.00,0.00,0.00,350.00,'2026-06-05 09:34:11','2026-06-05 09:34:11','2026-06-05 09:34:11');
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `regions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `regions_org_name_unique` (`organization_id`,`name`),
  CONSTRAINT `regions_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES
(3,1,'Абай'),
(4,1,'Альфараби'),
(1,1,'Енбекши'),
(2,1,'Каратау');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `streets`
--

DROP TABLE IF EXISTS `streets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `streets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `region_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `streets_org_region_name_unique` (`organization_id`,`region_id`,`name`),
  KEY `streets_region_id_foreign` (`region_id`),
  KEY `streets_org_region_idx` (`organization_id`,`region_id`),
  CONSTRAINT `streets_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `streets_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `streets` WRITE;
/*!40000 ALTER TABLE `streets` DISABLE KEYS */;
INSERT INTO `streets` VALUES
(12,1,3,'А.Оразбаева'),
(11,1,3,'Аманжар'),
(4,1,3,'Багова'),
(13,1,3,'Дачная '),
(9,1,3,'Елетов'),
(8,1,3,'Ергобек '),
(6,1,3,'Ерубаев'),
(14,1,3,'Ешназаров '),
(17,1,3,'Жумабаев'),
(3,1,3,'Кенжеханов'),
(19,1,3,'Кудайберді'),
(2,1,3,'Мадалиев'),
(1,1,3,'мкр Сайрам'),
(16,1,3,'Мусабек Батыр(Некрасов)'),
(15,1,3,'Сапак би'),
(20,1,3,'Север'),
(5,1,3,'Тлеубердин'),
(10,1,3,'Турымбетов'),
(18,1,3,'Царские дома');
/*!40000 ALTER TABLE `streets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tariffs`
--

DROP TABLE IF EXISTS `tariffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `utility_service_id` bigint(20) unsigned NOT NULL,
  `client_type` varchar(255) NOT NULL,
  `unit_price` decimal(14,2) DEFAULT NULL,
  `per_person_price` decimal(14,2) DEFAULT NULL,
  `starts_on` date NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tariffs_utility_service_id_foreign` (`utility_service_id`),
  KEY `tariffs_period_idx` (`organization_id`,`starts_on`),
  KEY `tariffs_lookup_idx` (`organization_id`,`utility_service_id`,`client_type`,`status`),
  CONSTRAINT `tariffs_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tariffs_utility_service_id_foreign` FOREIGN KEY (`utility_service_id`) REFERENCES `utility_services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariffs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tariffs` WRITE;
/*!40000 ALTER TABLE `tariffs` DISABLE KEYS */;
INSERT INTO `tariffs` VALUES
(1,1,1,'individual',70.00,400.00,'2026-01-01','active','2026-06-04 11:30:01','2026-06-04 11:30:42');
/*!40000 ALTER TABLE `tariffs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Admin','admin@eseply.kz',NULL,'$2y$12$ys7wykJjwnY4MKBtDmoeKe.4P2QKwWXeLvdjYA4LbW3yhnJjnyN6y','08rQIFdcVdozxpO7dVKwTC0lgAEGYRNc6MNwO6aTxlSRJtjdteCOjw8FotNw','2026-05-30 13:41:57','2026-05-30 13:41:57'),
(2,'Раманкулов Суймхан','chin84galaxy@gmail.com',NULL,'$2y$12$tc9EG3InPEon11ftHiSUyOhaZtWOsymBefBz.OH4dfzBAgkQb/A6O',NULL,'2026-06-05 07:58:26','2026-06-05 07:58:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `utility_services`
--

DROP TABLE IF EXISTS `utility_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `utility_services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `unit_of_measurement` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `utility_services_organization_id_unique` (`organization_id`),
  KEY `utility_services_organization_id_status_index` (`organization_id`,`status`),
  CONSTRAINT `utility_services_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utility_services`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `utility_services` WRITE;
/*!40000 ALTER TABLE `utility_services` DISABLE KEYS */;
INSERT INTO `utility_services` VALUES
(1,1,'вода','м3','active',NULL,'2026-06-01 06:40:19','2026-06-01 06:40:19');
/*!40000 ALTER TABLE `utility_services` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'eseply_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-06-05 11:54:43
